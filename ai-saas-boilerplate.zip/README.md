# AI SaaS Boilerplate

This repository contains a minimal production-ready scaffold for an AI-powered SaaS:
- Frontend: static HTML/CSS/JS (served by nginx in docker-compose)
- Backend: FastAPI (Python) with SQLModel/Postgres
- Worker: RQ (Redis) example + FastAPI background tasks
- Docker & docker-compose for local dev
- Terraform skeleton for AWS infra
- GitHub Actions CI skeleton

How to run locally (docker-compose):
1. Copy backend/.env.example to backend/.env and set OPENAI_API_KEY if available.
2. docker-compose up --build
3. Visit http://localhost:8080 (frontend) and http://localhost:8000/api/health

Notes:
- This is a scaffold: adapt production settings, secrets handling, and security before deploying.
