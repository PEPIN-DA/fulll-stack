const API_URL = window.__API_URL__ || (location.origin.replace(/:\d+$/, '') + ':8000');

async function analyzeUrl(url){
  const res = await fetch(API_URL + '/api/analyze', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ url })
  });
  return res.json();
}

document.getElementById('analyze').addEventListener('click', async ()=>{
  const url = document.getElementById('url').value.trim();
  if(!url){ alert('Enter a URL'); return; }
  document.getElementById('output').textContent = 'Analyzing...';
  try{
    const data = await analyzeUrl(url);
    document.getElementById('output').textContent = JSON.stringify(data, null, 2);
  }catch(e){
    document.getElementById('output').textContent = 'Error: '+e.message;
  }
});
