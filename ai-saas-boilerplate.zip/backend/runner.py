from app.db import init_db
init_db()
print('DB init completed.')
