# Backend (FastAPI) for AI SaaS Boilerplate

This backend provides:
- /api/analyze -> accepts { url } and enqueues a job
- /api/analyze/{id} -> get analysis record
- /api/health -> health check

Run locally with docker-compose (recommended).
