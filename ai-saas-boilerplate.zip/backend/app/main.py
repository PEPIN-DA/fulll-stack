from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .routes import analyze, health

app = FastAPI(title="AI SaaS Boilerplate")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # restrict in prod
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(health.router, prefix="/api")
app.include_router(analyze.router, prefix="/api/analyze")
