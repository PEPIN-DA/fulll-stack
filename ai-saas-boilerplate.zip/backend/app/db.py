from typing import Optional
from sqlmodel import SQLModel, Field, create_engine, Session
import os

DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://postgres:postgres@db:5432/postgres")
engine = create_engine(DATABASE_URL, echo=False)

class Analysis(SQLModel, table=True):
    id: Optional[str] = Field(default=None, primary_key=True)
    url: str
    status: str = "pending"
    suggestions: Optional[str] = None

    @classmethod
    def create(cls, url):
        from uuid import uuid4
        a = cls(id=str(uuid4()), url=url, status="pending")
        with Session(engine) as s:
            s.add(a); s.commit(); s.refresh(a)
        return a

    @classmethod
    def get(cls, id_):
        with Session(engine) as s:
            return s.get(cls, id_)

    def to_dict(self):
        return {"id": self.id, "url": self.url, "status": self.status, "suggestions": self.suggestions}

def init_db():
    SQLModel.metadata.create_all(engine)
