import os
from ..db import engine, Analysis
import httpx
from openai import OpenAI

OPENAI_KEY = os.getenv("OPENAI_API_KEY", "")

async def fetch_html(url):
    async with httpx.AsyncClient(timeout=15.0, follow_redirects=True) as client:
        r = await client.get(url)
        r.raise_for_status()
        return r.text

def call_openai(prompt):
    client = OpenAI(api_key=OPENAI_KEY)
    resp = client.chat.completions.create(model='gpt-4o-mini', messages=[{'role':'user','content':prompt}])
    return resp.choices[0].message.content

def process_analysis(analysis_id, url):
    from sqlmodel import Session
    with Session(engine) as s:
        a = s.get(Analysis, analysis_id)
        if not a:
            return
        a.status = "running"
        s.add(a); s.commit()

    try:
        html = None
        try:
            import asyncio
            html = asyncio.run(fetch_html(url))
        except Exception as e:
            html = f"fetch_error: {e}"

        prompt = f"Analyze this page and give me 5 high level suggestions:\\n{html[:3000]}"
        ai_result = "AI_DISABLED" if not OPENAI_KEY else call_openai(prompt)

        with Session(engine) as s:
            a = s.get(Analysis, analysis_id)
            a.status = "done"
            a.suggestions = ai_result
            s.add(a)
            s.commit()
    except Exception as e:
        with Session(engine) as s:
            a = s.get(Analysis, analysis_id)
            a.status = "failed"
            a.suggestions = str(e)
            s.add(a); s.commit()
