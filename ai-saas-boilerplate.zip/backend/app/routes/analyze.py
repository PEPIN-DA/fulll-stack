from fastapi import APIRouter, HTTPException, BackgroundTasks
from pydantic import BaseModel, HttpUrl
from ..services import analyzer_service
from ..db import Analysis

router = APIRouter()

class AnalyzeIn(BaseModel):
    url: HttpUrl

@router.post("/", status_code=202)
async def analyze_endpoint(payload: AnalyzeIn, background_tasks: BackgroundTasks):
    # create DB record
    analysis = Analysis.create(url=str(payload.url))
    background_tasks.add_task(analyzer_service.process_analysis, analysis.id, str(payload.url))
    return {"id": analysis.id, "status":"pending"}
    
@router.get("/{analysis_id}")
async def get_analysis(analysis_id: str):
    record = Analysis.get(analysis_id)
    if not record:
        raise HTTPException(404, "Not found")
    return record.to_dict()
